﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;

namespace SVNRevisionNumberXML
{
    class Program
    {
        static void Main(string[] args)
        {
            string revision = "-1";

            try
            {
                string xmlFile = args[0];
                string outPutfile = args[1];

                Console.WriteLine(">SVNRevisionNumberXML:");
                Console.WriteLine(">Parsing: " + xmlFile);

                XmlTextReader reader = new XmlTextReader(xmlFile);
                reader.ReadStartElement("info");

                while (reader.Read())
                {
                    if (reader.Name == "commit")
                    {
                        revision = reader.GetAttribute("revision");
                        break;
                    }
                }
                reader.Close();

                Console.WriteLine(">Writing output to: " + outPutfile);
                StreamWriter st = new StreamWriter(outPutfile);
                st.Write(revision);
                st.Close();
                st.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(">" + ex.Message);
            }
        }
    }
}
